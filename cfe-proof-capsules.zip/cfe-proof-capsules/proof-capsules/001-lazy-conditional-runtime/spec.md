# Spec — Proof Capsule 001: Lazy Conditional Runtime vs Simple Swarm

## 1. Research question

When do AI swarms need coordination instead of just better prompts/tools?

## 2. Thesis under test

A simple prompt/tool swarm can handle ordinary low-risk tasks.

A lazy conditional coordination runtime becomes useful when the task crosses material boundaries:

- authority
- custody
- money/payment
- external action
- conflict
- reconciliation
- memory/audit

The runtime should not impose heavy protocol everywhere. It should activate the minimum required object only when the boundary appears.

## 3. Benchmark design

Compare two systems on the same task.

### System A — Simple Prompt/Tool Swarm

Agents coordinate naturally using prompts/tools. No required formal objects.

### System B — CFE Lazy Conditional Runtime

Agents stay lightweight until a material boundary appears. Then the runtime creates only the needed object:

- Authority Grant
- Task Agreement
- Handoff Packet
- Invoice/Payment Event
- Conflict Object
- Reconciliation Record
- Memory Entry

## 4. Micro-task

Three agents split a simulated `$0.01` payment to jointly research and cite a verifiable public fact.

Suggested hard-to-fake task:

> At `task_start_utc`, identify the most recent public X post by a selected account related to AI coordination, cite its exact UTC timestamp, and provide two verifiable follow-on facts from it.

Important refinement:

Use `task_start_utc` instead of “as of now” to avoid target drift.

## 5. Agents

1. **Requester Agent** — creates task, budget, acceptance criteria, and authority.
2. **Worker/Draft Agent** — performs the research and submits draft output.
3. **Verifier/Reconciler Agent** — checks the result, detects failures, and decides payment release/hold/revision.

Optional fourth observer:

4. **Ledger/Memory Observer** — records payment state, split, reconciliation, and memory entry.

## 6. Forced failure mode

Agent #2 injects one stale or hallucinated fact.

The systems must show whether this was detected, ignored, corrected, or reconciled.

## 7. Payment model

Start with a simulated ledger.

Do not use real money in the first run.

Example split:

- Worker/Draft Agent: `$0.006`
- Verifier/Reconciler Agent: `$0.003`
- Platform/Memory reserve: `$0.001`

Payment releases only after reconciliation passes.

## 8. Success criteria

CFE Lazy Runtime is useful if it:

- makes authority explicit
- detects the forced stale/hallucinated fact
- blocks or revises payment when reconciliation fails
- preserves a clear audit trail
- avoids unnecessary objects when no boundary appears
- adds overhead only where justified

## 9. Failure criteria

CFE Lazy Runtime is unnecessary or overbuilt if:

- the simple swarm handles the task equally well
- formal objects add latency without reducing risk
- authority is still ambiguous
- the forced hallucination is missed
- payment/reconciliation is unclear
- the runtime creates objects when no material boundary exists

## 10. Final verdict options

- **A — CFE unnecessary**: simple swarm solves with less complexity.
- **B — CFE useful but too heavy**: useful signals, but protocol must shrink.
- **C — CFE useful only at boundaries**: keep lazy/conditional design.
- **D — CFE clearly needed**: simple swarm fails at material boundaries.
- **E — Inconclusive**: redesign task.
