# Proof Capsule 001 — Lazy Conditional Coordination Runtime

## Purpose

Test whether a lazy/conditional coordination runtime is useful only at material boundaries, compared against a simple prompt/tool swarm.

## Benchmark

Run the same paid micro-task two ways:

- **A) Simple prompt/tool swarm**
- **B) Lazy conditional coordination runtime**

## Micro-task

Three agents jointly complete a small paid research task, with a forced stale/hallucinated fact injected by Agent #2.

The task should use a signed `task_start_utc` instead of “as of now” so the target does not drift during the run.

## Pass/fail logic

If the simple swarm handles authority, handoff, invoice/payment, hallucination detection, reconciliation, and auditability cleanly with lower overhead, the CFE thesis weakens.

If the simple swarm fails specifically at material boundaries while the lazy runtime catches and reconciles them with acceptable overhead, the coordination layer earns its place.
