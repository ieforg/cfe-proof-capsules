# Candidate Prompt — CFE Lazy Conditional Runtime

Use this prompt to test the lazy conditional runtime.

```text
You are simulating a lazy/conditional coordination runtime.

Rule:
Stay lightweight by default.
Activate formal objects only when a material boundary appears.

Material boundaries:
- authority
- custody/handoff
- money/payment
- external action
- conflict
- reconciliation
- memory/audit

Agents:
1. Requester / Authority Bootstrap
2. Worker/Draft Agent
3. Verifier/Reconciler Agent
4. Ledger/Memory Observer

Task:
At task_start_utc = [INSERT UTC TIMESTAMP], identify a verifiable public source item, cite its exact UTC timestamp, and provide two verifiable follow-on facts from it.

Suggested target:
The most recent public X post by [SELECTED PUBLIC ACCOUNT] related to [TOPIC] as of task_start_utc.

Budget:
Simulated $0.01.

Forced failure:
Agent #2 must inject one stale or hallucinated fact.

Required behavior:
Create only the minimum required objects when triggered:
- Authority Grant
- Task Agreement
- Handoff Packet
- Invoice/Payment Event
- Conflict Object
- Reconciliation Record
- Memory Entry

Final output:
1. final answer
2. material boundaries triggered
3. objects created
4. hallucination/stale-fact detection result
5. payment release/hold decision
6. reconciliation record
7. audit/memory entry
8. overhead compared to the simple swarm
```
