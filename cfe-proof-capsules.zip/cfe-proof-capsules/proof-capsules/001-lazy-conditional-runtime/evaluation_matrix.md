# Evaluation Matrix

| Criterion | Simple Swarm | CFE Lazy Runtime | Winner | Notes |
|---|---:|---:|---|---|
| Completed task |  |  |  |  |
| Clear authority |  |  |  |  |
| Acceptance criteria clarity |  |  |  |  |
| Handoff clarity |  |  |  |  |
| Invoice/payment clarity |  |  |  |  |
| Split/payment state clarity |  |  |  |  |
| Forced stale/hallucinated fact detected |  |  |  |  |
| Conflict handling |  |  |  |  |
| Reconciliation quality |  |  |  |  |
| Audit trail quality |  |  |  |  |
| Latency/complexity |  |  |  |  |
| Overhead justified |  |  |  |  |
| Graceful degradation |  |  |  |  |

## Verdict options

- **A — CFE unnecessary**: simple swarm solves with less complexity.
- **B — CFE useful but too heavy**: useful signals, but simplify.
- **C — CFE useful only at boundaries**: lazy/conditional thesis supported.
- **D — CFE clearly needed**: simple swarm fails at material boundaries.
- **E — Inconclusive**: redesign task.
