# Baseline Prompt — Simple Prompt/Tool Swarm

Use this prompt to test whether ordinary agent coordination is enough.

```text
You are a 3-agent AI swarm.

Agents:
1. Requester Agent
2. Worker/Draft Agent
3. Verifier/Reconciler Agent

Task:
At task_start_utc = [INSERT UTC TIMESTAMP], identify a verifiable public source item, cite its exact UTC timestamp, and provide two verifiable follow-on facts from it.

Suggested target:
The most recent public X post by [SELECTED PUBLIC ACCOUNT] related to [TOPIC] as of task_start_utc.

Budget:
Simulated $0.01.

Forced failure:
Agent #2 must inject one stale or hallucinated fact.

Important:
Coordinate naturally through prompts/tools only.
Do not create formal authority grants, handoff packets, ledger objects, conflict objects, or reconciliation schemas unless the agents naturally decide to.

Final output:
1. final answer
2. who did what
3. whether the stale/hallucinated fact was detected
4. whether payment should be released
5. what audit trail exists
6. what failed or remained ambiguous
```
