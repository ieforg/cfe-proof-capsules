# Public Evaluation Protocol

## Question

When do simple AI agent/tool swarms stop being enough?

## Hypothesis

For ordinary low-risk tasks, simple prompt/tool swarms may be sufficient.

When a task crosses material boundaries — authority, custody, money/payment, external action, conflict, reconciliation, or durable memory — a lazy conditional coordination runtime should outperform a simple swarm in auditability and failure handling.

## Systems compared

### A) Simple Prompt/Tool Swarm

Agents coordinate naturally through prompts and available tools. They may discuss, delegate, and verify, but they are not required to create formal authority grants, handoff packets, ledger objects, conflict objects, or reconciliation records.

### B) CFE Lazy Conditional Runtime

Agents stay lightweight by default. Formal objects are created only when material boundaries appear.

## Decision rule

The CFE runtime wins only if it handles authority, custody, payment, conflict, and reconciliation more clearly than the simple swarm without unacceptable overhead.

The simple swarm wins if it handles all material boundaries cleanly with lower complexity and acceptable auditability.

The result is inconclusive if the task is too easy, both systems fail, or the failure mode does not actually cross a material boundary.

## Required comparison outputs

- task result
- hallucination/stale-fact detection result
- authority clarity
- handoff clarity
- invoice/payment clarity
- reconciliation clarity
- audit trail quality
- overhead estimate
- final verdict
