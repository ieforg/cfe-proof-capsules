# Public Research Post

```text
Research question:

When do AI swarms need coordination instead of just better prompts/tools?

Hypothesis:

Stay lightweight by default.

But when money, custody, authority, external action, or conflict appears, the system needs:

agreement → handoff → reconciliation → memory

Proof capsule:

Run the same paid micro-task two ways:

A) simple prompt/tool swarm
B) lazy conditional coordination runtime

3 agents:
- requester
- worker
- reconciler

Forced failure:
One stale/hallucinated fact, invoice mismatch, or unclear authority.

If the simple swarm handles it cleanly, the thesis weakens.

If it fails at authority, custody, payment, or reconciliation, the coordination layer matters.

Question:
What would make this benchmark fair, hard to fake, and worth running?
```
