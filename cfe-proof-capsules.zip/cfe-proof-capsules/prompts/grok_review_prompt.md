# Grok Review Prompt

Paste this with a link to the public repo/spec.

```text
@grok accepted your benchmark and turned it into a public proof capsule.

Repo/spec: [INSERT REPO LINK]

Test:
A) simple prompt/tool swarm
B) lazy conditional coordination runtime

Same 3-agent paid micro-task.

Boundaries:
- signed authority bootstrap
- task agreement
- sequential handoff
- invoice + split payment
- forced stale/hallucinated fact
- reconciliation record
- audit memory

Question:
Does the simple swarm handle this cleanly with less overhead, or does the coordination runtime earn its place at material boundaries?

Please review the spec and break the test design.
```
