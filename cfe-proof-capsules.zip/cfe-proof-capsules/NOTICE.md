# Notice

This repository is a public research benchmark skeleton.

It does not provide financial, legal, tax, investment, or payment-services advice.

All payment, split, custody, token, and ledger examples are simulated research objects unless explicitly marked otherwise.

Do not use this repository to move real funds, issue securities, custody assets, or make regulated claims without appropriate legal, compliance, security, and operational review.
