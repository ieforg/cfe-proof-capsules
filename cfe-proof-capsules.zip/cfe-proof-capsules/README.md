# CFE Proof Capsules

Public research benchmarks for testing when simple AI prompt/tool swarms stop being enough.

## Core thesis

AI systems should stay **lightweight by default**.

When a task crosses a material boundary — **authority, custody, money/payment, external action, conflict, reconciliation, or memory** — the system should create the minimum explicit structure needed: agreements, handoffs, reconciliation records, and audit memory.

The goal is not to add heavy protocol everywhere. The goal is to discover the exact boundary where a simple swarm becomes insufficient.

## Proof Capsule 001

[`001-lazy-conditional-runtime`](proof-capsules/001-lazy-conditional-runtime/spec.md) compares two systems on the same hard-to-fake paid micro-task:

- **A) Simple prompt/tool swarm** — agents coordinate through normal prompts/tools with no required formal runtime objects.
- **B) Lazy conditional coordination runtime** — agents remain lightweight until a material boundary appears, then create the minimum required state object.

### Test shape

Three agents complete a small paid research task:

1. **Requester** creates the task, budget, acceptance criteria, and authority grant.
2. **Worker** performs the research, submits work, and submits an invoice/payment request.
3. **Reconciler** verifies the output, detects a forced stale/hallucinated fact, and decides whether payment should be released, revised, or disputed.

### Forced failure mode

Agent #2 injects one stale or hallucinated fact.

### Material boundaries tested

- signed authority bootstrap
- task agreement
- sequential handoff
- invoice/payment event
- split payment record
- hallucination/conflict detection
- reconciliation record
- audit/memory entry

## Current status

Research skeleton. No real payments. No real custody. No investment product. All payment and ledger objects are simulated until explicitly replaced by a real payment rail/testnet in a later experiment.

## Fast reading path for LLM reviewers

1. [`repo_manifest.json`](repo_manifest.json)
2. [`proof-capsules/001-lazy-conditional-runtime/spec.md`](proof-capsules/001-lazy-conditional-runtime/spec.md)
3. [`proof-capsules/001-lazy-conditional-runtime/baseline_simple_swarm.md`](proof-capsules/001-lazy-conditional-runtime/baseline_simple_swarm.md)
4. [`proof-capsules/001-lazy-conditional-runtime/cfe_lazy_runtime.md`](proof-capsules/001-lazy-conditional-runtime/cfe_lazy_runtime.md)
5. [`proof-capsules/001-lazy-conditional-runtime/evaluation_matrix.md`](proof-capsules/001-lazy-conditional-runtime/evaluation_matrix.md)

## One-line summary

**Lightweight until value moves. Accountable when authority, custody, money, external action, or conflict appears.**
